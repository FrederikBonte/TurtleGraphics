﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ROCvanTwente.Sumpel.Semester1.TurtleDrawing
{
    public class Turtle
    {
        private const float TORAD = (float)Math.PI / 180;
        private const float SX = 60f/4;
        private const float SY = 66.5f/4;
        private const float DRAW_SPEED = 5f;
        private Bitmap image;
        private Graphics ig;
        private Color color = Color.Black;
        private float thickness = 2f;
        private float x = 0;
        private float y = 0;
        private float angle = 0;
        private float dx, dy;
        private readonly Queue<TurtleAction> actions;
        private bool loop = false, stop = false, penDown = true;
        private Thread thread = null;
        private int delay = 100;

        internal Turtle(Bitmap image)
        {
            this.setImage(image);
            this.asyncReset();
            this.actions = new Queue<TurtleAction>();
        }

        public void drawTurtle(Graphics graphics)
        {
            graphics.DrawImage(GraphicsUtilities.Properties.Resource.turtle, getDestPoints());
        }

        private PointF[] getDestPoints()
        {
            PointF[] result = new PointF[3];
            float fx = dx;
            float fy = dy;
            float rx = -dy;
            float ry = dx;
            result[0] = new PointF(x + fx * SX - rx * SY, y + fy * SX - ry * SY);
            result[1] = new PointF(x + fx * SX + rx * SY, y + fy * SX + ry * SY);
            result[2] = new PointF(x - fx * SX - rx * SY, y - fy * SX - ry * SY);
            return result;
        }

        internal void setImage(Bitmap image)
        {
            this.image = image;
            this.ig = Graphics.FromImage(this.image);
            this.ig.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        }

        public void setDelay(int delay)
        {
            this.delay = Math.Max(0, Math.Min(delay, 1000));
        }

        public void clear()
        {
            this.halt();
            this.actions.Clear();
        }

        public void reset()
        {
            this.actions.Enqueue(new Reset(this));
        }

        public void rotate(float angle)
        {
            this.actions.Enqueue(new Rotate(this, angle));
        }

        public void setAngle(float angle)
        {
            this.actions.Enqueue(new SetAngle(this, angle));
        }

        public void moveForward(float distance)
        {
            this.actions.Enqueue(new Forward(this, distance));
        }

        public void setColor(Color color)
        {
            this.actions.Enqueue(new SetColor(this, color));
        }

        public void setThickness(float thickness)
        {
            this.actions.Enqueue(new SetThickness(this, thickness));

        }

        public void run(bool loop = false)
        {
            if (this.thread!=null)
            {
                this.halt();
                thread.Join();
            }
            this.loop = loop;
            this.stop = false;
            this.thread = new Thread(new ThreadStart(asyncRun));
            this.thread.Start();
        }

        public void halt()
        {
            this.stop = true;
        }

        internal void asyncRun()
        {
            while (this.actions.Count>0 && !stop)
            {
                TurtleAction action = this.actions.Dequeue();
                action.run();
                if (loop)
                {
                    this.actions.Enqueue(action);
                }
            }
            this.thread = null;
        }

        internal void asyncReset()
        {
            this.x = this.image.Width / 2;
            this.y = this.image.Height / 2;
            this.angle = 0;
            this.dx = 0;
            this.dy = -1;
        }

        internal void asyncRotate(float delta_angle)
        {
            asyncSetAngle(this.angle + delta_angle);
        }

        internal void asyncSetAngle(float new_angle)
        {
            angle = new_angle;
            while (angle>360)
            {
                angle -= 360;
            }
            while (angle<0)
            {
                angle += 360;
            }
            this.dy = -(float)Math.Cos(angle * TORAD);
            this.dx = (float)Math.Sin(angle * TORAD);
        }

        internal void asyncMoveForward(float distance)
        {
            while (distance>0)
            {
                float tx = this.x + this.dx * Math.Min(distance, DRAW_SPEED);
                float ty = this.y + this.dy * Math.Min(distance, DRAW_SPEED);
                if (penDown)
                {
                    Pen p = new Pen(this.color, this.thickness);
                    p.StartCap = System.Drawing.Drawing2D.LineCap.Round;
                    p.EndCap = System.Drawing.Drawing2D.LineCap.Round;
                    ig.DrawLine(p, x, y, tx, ty);
                }
                this.x = tx;
                this.y = ty;
                distance -= DRAW_SPEED;
                if (delay > 0)
                {
                    Thread.Yield();
                    Thread.Sleep(delay);
                }
            }
        }

        internal void asyncPenUp()
        {
            this.penDown = false;
        }

        internal void asyncPenDown()
        {
            this.penDown = true;
        }

        internal void asyncSetColor(Color color)
        {
            this.color = color;
        }

        internal void asyncSetThickness(float thickness)
        {
            this.thickness = thickness;
        }

        internal abstract class TurtleAction
        {
            protected readonly Turtle turtle;
            public TurtleAction(Turtle turtle)
            {
                this.turtle = turtle;
            }

            public abstract void run();
        }

        internal class Reset : TurtleAction
        {
            public Reset(Turtle turtle) : base(turtle)
            {
            }

            public override void run()
            {
                turtle.asyncReset();
            }
        }

        internal class PenUp : TurtleAction
        {
            public PenUp(Turtle turtle) : base(turtle)
            {
            }

            public override void run()
            {
                turtle.asyncPenUp();
            }
        }

        internal class PenDown : TurtleAction
        {
            public PenDown(Turtle turtle) : base(turtle)
            {
            }

            public override void run()
            {
                turtle.asyncPenDown();
            }
        }

        internal class Forward : TurtleAction
        {
            private readonly float distance;

            public Forward(Turtle turtle, float distance) : base(turtle)
            {
                this.distance = distance;
            }

            public override void run()
            {
                turtle.asyncMoveForward(distance);
            }
        }
        internal class Rotate : TurtleAction
        {
            private readonly float angle;

            public Rotate(Turtle turtle, float angle) : base(turtle)
            {
                this.angle = angle;
            }

            public override void run()
            {
                turtle.asyncRotate(angle);
            }
        }

        internal class SetAngle : TurtleAction
        {
            private readonly float angle;

            public SetAngle(Turtle turtle, float angle) : base(turtle)
            {
                this.angle = angle;
            }

            public override void run()
            {
                turtle.asyncSetAngle(angle);
            }
        }

        internal class SetColor : TurtleAction
        {
            private readonly Color color;

            public SetColor(Turtle turtle, Color color) : base(turtle)
            {
                this.color = color;
            }

            public override void run()
            {
                turtle.asyncSetColor(color);
            }
        }

        internal class SetThickness : TurtleAction
        {
            private readonly float thickness;

            public SetThickness(Turtle turtle, float thickness) : base(turtle)
            {
                this.thickness = thickness;
            }

            public override void run()
            {
                turtle.asyncSetThickness(thickness);
            }
        }
    }
}
