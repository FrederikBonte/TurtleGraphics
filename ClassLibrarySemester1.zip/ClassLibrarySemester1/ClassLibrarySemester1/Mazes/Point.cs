﻿namespace ROCvanTwente.Sumpel.Semester2.MazeGenerator
{
    internal class Point
    {
        public int X, Y;

        public Point(int X, int Y)
        {
            this.X = X;
            this.Y = Y;
        }
    }
}